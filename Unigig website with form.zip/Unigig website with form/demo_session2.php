<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

  <?php
  if ($_SERVER['REQUEST_METHOD'] =="POST") {
  $con = mysql_connect("localhost","hnd15har12121031","password");
  if (!$con){die('Could not connect: ' . mysql_error());}
// Echo session variables that were set on previous page
echo "Favorite color is " . $_SESSION["favcolor"] . ".<br>";
echo "Favorite animal is " . $_SESSION["favanimal"] . ".";
?>

</body>
</html>
