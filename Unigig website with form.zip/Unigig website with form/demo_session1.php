<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<body>

  <?php
  if ($_SERVER['REQUEST_METHOD'] =="POST") {
  $con = mysql_connect("localhost","hnd15har12121031","password");
  if (!$con){die('Could not connect: ' . mysql_error());}
// Set session variables
$_SESSION["favcolor"] = "green";
$_SESSION["favanimal"] = "cat";
echo "Session variables are set.";
?>

</body>
</html>
