<?php
// Start the session
session_start();
?>


<!DOCTYPE html>
<head>
<title>PHPRO Login</title>
</head>

<body>
  <?php
// Set session variables
$_SESSION["EmailAddress"] = "calum.harrison@outlook.com";
$_SESSION["Password"] = "Password";
echo "Session variables are set.";
?>
<h2>Login Here</h2>
<form action="check_login.php" method="post">
<fieldset>
<p>

<li>
  <label for="email address">Email *</label>
  <!-- email -->
<input type="email"  name="EmailAddress" id="EmailAddress" pattern="[^ @]*@[^ @]*" value="" required id="c" autocomplete="off" />
</li>
</p>
<p>
  <label for="mypassword">Password</label>
  <input type="password" name="Password" id="Password" />
</li>
</p>
<p>
<input type="submit" value="→ Login" />
</p>
</fieldset>
</form>
</body>
</html>
