<?php
session_start();
?>


<!DOCTYPE html>
<html>
<body>
<?php



$host="localhost"; // Host name
$username="hnd15har12121031"; // Mysql username
$password="password"; // Mysql password
$db_name="Customer"; // Database name
$tbl_name="Customer"; // Table name
if ($_SERVER['REQUEST_METHOD'] =="POST") {
$con = mysql_connect("localhost","hnd15har12121031","password");
if (!$con){die('Could not connect: ' . mysql_error());}
$EmailAddress=$_POST['EmailAddress'];
$Password=$_POST['Password'];

// Echo session variables that were set on previous page
echo "username set " . $_SESSION["EmailAddress"] . ".<br>";
echo "password set " . $_SESSION["password"] . ".";
}
else {
echo "Wrong email or Password";
}
?>
?>


</body>
</html>
