<!DOCTYPE html>
<html>

        <link rel="stylesheet" href="css/tablestyle.css">
<body>

<?php
//session start//
session_start();
//php connect to the server//
$con = mysql_connect("localhost","hnd15har12121031","password");
if (!$con){die('Could not connect: ' . mysql_error());}
//allow for a double query for a insertion into the database //
mysql_select_db("hnd15har12121031", $con);
$result = mysql_query("SELECT * FROM Product");
echo "<table border='1'> <tr>
<td>ID</td> <td>show</td> <td>venue</td> <td>seat number</td> <td>product description</td> <td>product amount</td>
<td>Comment</td> </tr>";
while($row = mysql_fetch_array($result)) {
echo "<tr>";
echo "<td>" . $row['ProductID'] . "</td>"; echo "<td>" . $row['ProductShow'] . "</td>";
echo "<td>" . $row['Venue'] . "</td>"; echo "<td>" . $row['SeatNumber'] . "</td>";
echo "<td>" . $row['ProductDescription'] . "</td>"; echo "<td>" . $row['ProductAmount'] . "</td>";
echo "</tr>";
}
echo "</table>";
mysql_close($con)
//session variale set//
//insert query for the address//
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<!--style sheets applied-->
	<meta charset="utf-8" />
	<title>Form Sample</title>

</head>


<a href="indexx.html">  <button class="btn btn-1 btn-1e">Log out</button>
<p> Hello well done!</p>

</body>
</html>

</body>
</html>
