<?php
session_start();
if(isset($_SESSION['Customer'])!="")
{
 header("Location: home.php");
}
include_once 'Dbconnect.php';

if(isset($_POST['btn-signup']))
{
 $Forename = mysql_real_escape_string($_POST['Forename']);
 $EmailAddress = mysql_real_escape_string($_POST['EmailAddress']);
 $Password = md5(mysql_real_escape_string($_POST['Password']));

 if mysql_query("INSERT INTO Customer(Forename,Surname,TelephoneNumber,DateOfBirth,Password,PasswordConf,EmailAddress)
 VALUES ('$_POST[Forename]','$_POST[Surname]','$_POST[Forename]','$_POS[TelephoneNumber]','$_POST[Password]',$POST[PasswordConf]','$POST[DateOfBirth]','$_POST[EmailAddress]')");
$Customer = mysql_insert_id();
mysql_query("INSERT INTO Address (Postcode,TownCity,County,AddressOne,CustomerID) VALUES ('$_POST[AddressOne]','$_POST[Postcode]','$_POST[TownCity]','$POST_[County]',$Customer)");()
mysql_close($con); }
 {
  ?>
        <script>alert('successfully registered ');</script>
        <?php
 }
 else
 {
  ?>
        <script>alert('error while registering you...');</script>
        <?php
 }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Form Sample</title>
	<link rel="stylesheet" href="normalize.css" />
	<link rel="stylesheet" href="mystyle.css" />
	<script src="modernizr_forms.js"></script>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.0/jquery.validate.min.js"></script>

<!--[if lt IE 8]>
	<style>
		legend {
			display: block;
			padding: 0;
			padding-top: 30px;
			font-weight: bold;
			font-size: 1.25em;
			color: #FFD98D;
			margin: 0 auto;
		}
	</style>
<![endif]-->

</head>
<body>
	<div class = "container">
	   <form id="myform" name="theform" class="group" action="process_page.php" method="POST">
	   	<fieldset id="login" title="Login Info">
	   		<legend>Login Info</legend>
	   		<span id="formerror" class="error"></span>
	   		<ol>
	   			<li>
	   				<label for="Forename">Forename*</label>
	   				<input type="text" name="Forename" id="Forename" title="Please enter your name" pattern="[A-Za-z ]+, [A-Za-z ]+" autofocus required placeholder="First" />
	   			</li>
	   			<li>
	   				<label for="Surname">Surname*</label>
	   				<input type="text" name="Surname" id="Surname" title="Please enter your name" pattern="[A-Za-z ]+, [A-Za-z ]+" autofocus required placeholder="Last" />
	   			</li>
	   			<li>
	   				<label for="email address">Email *</label>
	          <!-- email -->
	  <input type="email"  name="EmailAddress" id="EmailAddress" pattern="[^ @]*@[^ @]*" value="" required id="c" autocomplete="off" />
	   			</li>
	   			<li>
	   				<label for="Date Of Birth">Date Of Birth*</label>
	   				<input type="date" step=7 min=1900-00-00 name="Date Of Birth" required id="DateOfBirth" autocomplete="off" />
	   			</li>
	   			<li>
	   				<label for="mypassword">Password</label>
	   				<input type="password" name="Password" id="Password" />
	   			</li>
	   			<li>
	   				<label for="mypasswordconf">Password</label>
	   				<input type="password" name="PasswordConf" id="PasswordConf" />
	   			</li>
	   			<li>
	   				<label for="mytelephone">Telephone</label>
	   				<input type="tel" name="TelephoneNumber" id="TelephoneNumber" pattern="\d{3}[\-]\d{3}[\-]\d{4}" placeholder="xxx-xxx-xxxx"/>
	   			</li>
	   		</ol>
	   	</fieldset>
	   	<fieldset id="other" class="hidden" title="Customer Address">
	   		<legend>Other</legend>
	   		<ol>
	   			<li>
	   	          <label for="address">Address</label>
	   	          <input type="text" name="address" id="address" required
	   	            placeholder="123 Any Street" autocomplete="billing street-address">
	   	</li>
	   	  <li>        <label for="Town">City/Town</label>
	   	          <input type="text" name="Town" id="Town" required
	   	            placeholder="Newcastle-Under-Lyme" autocomplete="billing locality">
	   								</li>

	   	          <li>    <label for="County">County</label>
	   	          <input type="text" name="County" id="County" list="County" required
	   	            placeholder="Staffordshire" autocomplete="billing region">
	   	</li>
	   	          <li>    <label for="Post-Code">Post-Code</label>
	   	          <input type="text" name="Post-Code" id="Post-Code" required 	  placeholder="10011" autocomplete="billing postal-code" pattern="[A-Z]([A-Z]?)[1-9]([1-9]?) [1-9][A-Z][A-Z]" title="Postcode format including space e.g. ST5 2GB">


	   	</li>

	     		<button type="submit" name="btn-signup">Sign me up</button>
	   		</ol>
	   	</fieldset>
	   </form>
	   <script>
	$(document).ready(function() {
		$("#myform").validate({
				"rules" : {
					"mypassword": {
						"minlength" : 6,
						"required" : true },
					"mypasswordconf": {
						"equalTo" : "#mypassword"}
				} //rules
		}); //validate
	}); //document ready
</script>
</body>
</html>
