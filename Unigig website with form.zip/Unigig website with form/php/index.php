<?php
session_start();
include_once 'Dbconnect.php';

if(isset($_SESSION['Customer'])!="")
{
 header("Location: home.php");
}
if(isset($_POST['btn-login']))
{
 $EmailAddress = mysql_real_escape_string($_POST['EmailAddress']);
 $Password = mysql_real_escape_string($_POST['Password']);
 $res=mysql_query("SELECT * FROM Customer WHERE email='$EmailAddress'");
 $row=mysql_fetch_array($res);
 if($row['Password']==md5($Password))
 {
  $_SESSION['Customer'] = $row['CustomerID'];
  header("Location: home.php");
 }
 else
 {
  ?>
        <script>alert('wrong details');</script>
        <?php
 }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Form Sample</title>
	<link rel="stylesheet" href="normalize.css" />
	<link rel="stylesheet" href="mystyle.css" />
  	<link rel="stylesheet" href="php.css" />
	<script src="modernizr_forms.js"></script>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.0/jquery.validate.min.js"></script>
  </head>
  <body>
  	<div class = "container">
  	   <form id="myform" name="theform" class="group" action="process_page.php" method="POST">
  	   	<fieldset id="login" title="Login Info">
  	   		<legend>Login Info</legend>
  	   		<span id="formerror" class="error"></span>
  	   		<ol>
            <li>
              <label for="email address">Email *</label>
              <!-- email -->
      <input type="email"  name="EmailAddress" id="EmailAddress" pattern="[^ @]*@[^ @]*" value="" required id="c" autocomplete="off" />
            </li>
            <li>
  	   				<label for="mypassword">Password</label>
  	   				<input type="password" name="Password" id="Password" />
  	   			</li>
            <button type="submit" name="btn-login">Sign me up</button>
            <a href="register.php">Sign Up Here</a>
          </ol>
        </fieldset>
       </form>
       </body>
       </html>











<body>
<center>
<div id="login-form">
<form method="post">
<table align="center" width="30%" border="0">
<tr>
<td><input type="text" name="email" placeholder="Your Email" required /></td>
</tr>
<tr>
<td><input type="password" name="pass" placeholder="Your Password" required /></td>
</tr>
<tr>
<td><button type="submit" name="btn-login">Sign In</button></td>
</tr>
<tr>
<td><a href="register.php">Sign Up Here</a></td>
</tr>
</table>
</form>
</div>
</center>
</body>
</html>
