<?php
if ($_SERVER['REQUEST_METHOD'] =="POST") {
$con = mysql_connect("localhost","hnd15har12121031","password");
if (!$con){die('Could not connect: ' . mysql_error());}
mysql_select_db("hnd15har12121031", $con);
?> 
