<!DOCTYPE html>
<html>
<body>

<?php
//session start//
session_start();
//php connect to the server//
if ($_SERVER['REQUEST_METHOD'] =="POST") {
$con = mysql_connect("localhost","hnd15har12121031","password");
if (!$con){die('Could not connect: ' . mysql_error());}
//allow for a double query for a insertion into the database //
mysql_select_db("hnd15har12121031", $con);
mysql_query("INSERT INTO Customer(Forename,Surname,TelephoneNumber,DateOfBirth,Password,EmailAddress)
VALUES ('$_POST[Forename]','$_POST[Surname]','$_POST[TelephoneNumber]','$_POST[DateOfBirth]','$_POST[Password]','$_POST[EmailAddress]')");
echo "INSERT INTO Customer(Forename,Surname,TelephoneNumber,DateOfBirth,Password,EmailAddress)
VALUES ('$_POST[Forename]','$_POST[Surname]','$_POST[TelephoneNumber]','$_POST[DateOfBirth]','$_POST[Password]','$_POST[EmailAddress]')";
$Customer = mysql_insert_id();
//session variale set//
$_SESSION['Customer'] = $Customer;
//insert query for the address//
mysql_query("INSERT INTO Address (Postcode,TownCity,County,AddressOne,CustomerID) VALUES ('$_POST[Postcode]','$_POST[TownCity]','$_POST[County]','$_POST[AddressOne]',$Customer)");
mysql_close($con); }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<!--style sheets applied-->
	<meta charset="utf-8" />
	<title>Form Sample</title>
	<script src="modernizr_forms.js"></script>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.0/jquery.validate.min.js"></script>

	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="normalize.css" />
	<link rel="stylesheet" href="mystyle.css" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<!--[if lt IE 8]>
	<style>
		legend {
			display: block;
			padding: 0;
			padding-top: 30px;
			font-weight: bold;
			font-size: 1.25em;
			color: #FFD98D;
			margin: 0 auto;
		}
	</style>
<![endif]-->
<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button1 {
    background-color: white;
    color: black;
    border: 2px solid #4CAF50;
}

.button1:hover {
    background-color: #4CAF50;
    color: white;
}

</head>


Welcome <?php echo $_POST["Forename"]; ?><br>
Your email address is: <?php echo $_POST["EmailAddress"]; ?>


<body>
<a href="login.html">vist the vist page</a>
<p> Hello calum!</p>
</body>
</html>

</body>
</html>
