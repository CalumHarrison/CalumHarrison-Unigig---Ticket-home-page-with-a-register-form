<!DOCTYPE html>
<html>
<!--style sheets applied-->
<meta charset="utf-8" />
<title>Form Sample</title>
<script src="modernizr_forms.js"></script>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.0/jquery.validate.min.js"></script>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="normalize.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<a class="navbar-brand" href="#featured"><h1> <span class="subhead"></span></h1></a>
</div><!-- navbar-header -->
<div class="collapse navbar-collapse" id="collapse">
<ul class="nav navbar-nav navbar-right">
	<li class="active"><a href="indexx.html">Home</a></li>
	<li><a href="indexx.html">Products</a></li>
	<li><a href="indexx.html">Services</a></li>
	<li><a href="form.html">login</a></li>
</ul>
</div><!-- collapse navbar-collapse -->
</div><!-- container -->
</nav>
<style>
body {
padding-top: 50px;
}
#divTotal{
background-color: green;
data-spy="affix";
data-offset-top="20";

}
.affix{
right: 0px;
}
.affix-top{
right: 0px;
position: fixed;
}
</style>

</head>
<body>
	<p> welcome to the planet!</p>

<?php
if ($_SERVER['REQUEST_METHOD'] =="POST") {
$con = mysql_connect("localhost","hnd15har12121031","password");
if (!$con){die('Could not connect: ' . mysql_error());}
mysql_select_db("hnd15har12121031", $con);
mysql_query("INSERT INTO Customer(Forename,Surname,TelephoneNumber,DateOfBirth,Password,EmailAddress)
VALUES ('$_POST[Forename]','$_POST[Surname]','$_POST[TelephoneNumber]','$_POST[Password]','$_POST[DateOfBirth]','$_POST[EmailAddress]')");
echo "INSERT INTO Customer(Forename,Surname,TelephoneNumber,DateOfBirth,Password,EmailAddress)
VALUES ('$_POST[Forename]','$_POST[Surname]','$_POST[TelephoneNumber]','$_POST[Password]','$_POST[DateOfBirth]','$_POST[EmailAddress]')";
$Customer = mysql_insert_id();
mysql_query("INSERT INTO Address (Postcode,TownCity,County,AddressOne,CustomerID) VALUES ('$_POST[Postcode]','$_POST[TownCity]','$_POST[County]','$_POST[AddressOne]',$Customer)");
mysql_close($con); }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Form Sample</title>
	<script src="modernizr_forms.js"></script>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.0/jquery.validate.min.js"></script>

<!--[if lt IE 8]>
	<style>
		legend {
			display: block;
			padding: 0;
			padding-top: 30px;
			font-weight: bold;
			font-size: 1.25em;
			color: #FFD98D;
			margin: 0 auto;
		}
	</style>
<![endif]-->

</head>




Welcome <?php echo $_POST["Forename"]; ?><br>
Your email address is: <?php echo $_POST["EmailAddress"]; ?>
<body>
<p> welcome to the planet!</p>



			<a href="login.html">  <button class="btn btn-1 btn-1e">Login!</button>

</body>
</html>

</body>
</html>
