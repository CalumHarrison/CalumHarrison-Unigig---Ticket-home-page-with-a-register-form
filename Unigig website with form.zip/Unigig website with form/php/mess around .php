<!DOCTYPE html>

<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Unigig</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="js/prefixfree.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">



</head>

<body>

<header>
  <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#featured"><h1>UNIGIG <span class="subhead">Gigs 4 U</span></h1></a>
      </div><!-- navbar-header -->
      <div class="collapse navbar-collapse" id="collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="active"><a href="#featured">Home</a></li>
          <li><a href="#products">Products</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#login">login</a></li>
        </ul>
      </div><!-- collapse navbar-collapse -->
    </div><!-- container -->
  </nav>

  <div class="carousel fade" data-ride="carousel" id="featured">
    <ol class="carousel-indicators">
  </ol>

    <div class="carousel-inner fullheight">
      <div class="item"><img src="images/carousel-dj.jpg" alt="Lifestyle Photo"></div>
      <div class="item"><img src="images/carousel-gig1.jpg" alt="Vaccinations"></div>
      <div class="item"><img src="images/carousel-sil.jpg" alt="Fish"></div>
    </div><!-- carousel-inner -->

    <a class="left carousel-control" href="#featured" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
    </a>
    <a class="right carousel-control" href="#featured" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
    </a>
  </div><!-- featured carousel -->
</header>

<div class="main">
  <div class="page" id="products">
    <div class="content container">
      <h2>Products</h2>
      <div class="row">
        <article class="service col-md-6 col-sm-6 col-xs-12">
          <img class="icon" src="images/commerce 2.svg" alt="Icon">
          <h3>Disclosure</h3>
            </article>
            <article class="service col-md-6 col-sm-6 col-xs-12">
              <img class="icon" src="images/commerce 2.svg" alt="Icon">
              <h3>Rudimental</h3>
                </article>
                <div class="purchase-form">

                      <form action="/cart/add" method="post" id="cart_post">
                        <select id="variant-select" name="id" class="product-info-options">

                          <option value="17135249413">Disclousre - 16.00</option>

                        </select>
                        <input type="submit" value="Add to cart" class="btn btn-add">
                      </form>
                      <a href="#" class="hidden btn btn-waitlist">Waitlist</a>

                    </div>
                <form action="/cart/add" method="post" id="cart_post">
        <select id="variant-select" name="id" class="product-info-options">

          <option value="17135249413">Rudimental - 16.00</option>

        </select>
        <input type="submit" value="Add to cart" class="btn btn-add">
      </form>

      </div><!-- row -->
    </div><!-- content container -->
  </div><!-- mission page -->

  <div class="page" id="services">
    <div class="content container">
      <h2>Services</h2>
      <div class="row">
        <article class="service col-md-4 col-sm-6 col-xs-12">
          <img class="icon" src="images/technology-1.svg" alt="Icon">
          <h3>Exotic Pets</h3>
          <p>We offer specialized care for reptiles, rodents, birds, and other exotic pets.</p>
        </article>

        <article class="service col-md-4 col-sm-6 col-xs-12">
          <img class="icon" src="images/music.svg" alt="Icon">
          <h3>Global</h3>
          <p>Our therapeutic grooming treatments help battle fleas, allergic dermatitis, and other challenging skin conditions.</p>
        </article>

        <article class="service col-md-4 col-sm-6 col-xs-12">
          <img class="icon" src="images/food.svg" alt="Icon">
          <h3>GeneralHealth</h3>
          <p>Wellness and senior exams, ultrasound, x-ray, and dental cleanings are just a few of our general health services.</p>
        </article>

        <article class="service col-md-4 col-sm-6 col-xs-12">
          <img class="icon" src="images/technology.svg" alt="Icon">
          <h3>Discloure</h3>
          <p>Let our nutrition experts review your pet's diet and prescribe a custom nutrition plan for optimum health and disease prevention.</p>
        </article>

        <article class="service col-md-4 col-sm-6 col-xs-12">
          <img class="icon" src="images/music copy.svg" alt="Icon">
          <h3>Rudimental</h3>
          <p>We offer the latest advances in safe and effective prevention and treatment of fleas, ticks, worms, heart worm, and other parasites.</p>
        </article>

        <article class="service col-md-4 col-sm-6 col-xs-12">
          <img class="icon" src="images/musical.svg" alt="Icon">
          <h3>Ice Cube</h3>
          <p>Our veterinarians are experienced in modern vaccination protocols that prevent many of the deadliest diseases in pets.</p>
        </article>
      </div><!-- row -->
    </div><!-- content container -->
  </div><!-- services page -->
 <div class = "container">
   <form id="myform" name="theform" class="group" action="http://iviewsource.com" method="POST">
   	<fieldset id="login" title="Login Info">
   		<legend>Login Info</legend>
   		<span id="formerror" class="error"></span>
   		<ol>
   			<li>
   				<label for="forename">Forename*</label>
   				<input type="text" name="forename" id="forename" title="Please enter your name" pattern="[A-Za-z ]+, [A-Za-z ]+" autofocus required placeholder="First" />
   			</li>
   			<li>
   				<label for="Surname">Surname*</label>
   				<input type="text" name="Surname" id="myname" title="Please enter your name" pattern="[A-Za-z ]+, [A-Za-z ]+" autofocus required placeholder="Last" />
   			</li>
   			<li>
   				<label for="email address">Email *</label>
          <!-- email -->
  <input type="email"  name="EmailAddress" pattern="[^ @]*@[^ @]*" value="" required id="c" autocomplete="off" />
   			</li>
   			<li>
   				<label for="Date Of Birth">Date Of Birth*</label>
   				<input type="date" step=7 min=1900-00-00 name="Date Of Birth" required id="Date Of Birth" autocomplete="off" />
   			</li>
   			<li>
   				<label for="mypassword">Password</label>
   				<input type="password" name="mypassword" id="mypassword" />
   			</li>
   			<li>
   				<label for="mypasswordconf">Password</label>
   				<input type="password" name="mypasswordconf" id="mypasswordconf" />
   			</li>
   			<li>
   				<label for="mytelephone">Telephone</label>
   				<input type="tel" name="mytelephone" id="mytelephone" pattern="\d{3}[\-]\d{3}[\-]\d{4}" placeholder="xxx-xxx-xxxx"/>
   			</li>
   		</ol>
   	</fieldset>
   	<fieldset id="other" class="hidden" title="Customer Address">
   		<legend>Other</legend>
   		<ol>
   			<li>
   	          <label for="address">Address</label>
   	          <input type="text" name="address" id="address" required
   	            placeholder="123 Any Street" autocomplete="billing street-address">
   	</li>
   	  <li>        <label for="Town">City/Town</label>
   	          <input type="text" name="Town" id="Town" required
   	            placeholder="Newcastle-Under-Lyme" autocomplete="billing locality">
   								</li>

   	          <li>    <label for="County">County</label>
   	          <input type="text" name="County" id="County" list="County" required
   	            placeholder="Staffordshire" autocomplete="billing region">
   	</li>
   	          <li>    <label for="Post-Code">Post-Code</label>
   	          <input type="text" name="Post-Code" id="Post-Code" required 	  placeholder="10011" autocomplete="billing postal-code" pattern="[A-Z]([A-Z]?)[1-9]([1-9]?) [1-9][A-Z][A-Z]" title="Postcode format including space e.g. ST5 2GB">


   	</li>

     		<button type="submit">send</button>
   		</ol>
   	</fieldset>
   </form>
   <script>
   	$(document).ready(function() {
   		$("#myform").validate({
   				"rules" : {
   					"mypassword": {
   						"minlength" : 6,
   						"required" : true },
   					"mypasswordconf": {
   						"equalTo" : "#mypassword"}
   				} //rules
   		}); //validate
   	}); //document ready
   </script>

     <div class = "container">



     </div>

        </blockquote>
      </div>
    </div><!-- container -->
  </div><!-- testimonials page -->
</div><!-- main -->

<footer>
  <div class="content container-fluid">
    <div class="row">
      <div class="col-sm-6">
        <p>Call us toll-free at <span class="phone">888-555-1212</span></p>
        <img class="icon" src="images/s.svg" alt="Icon">
      </div><!-- col-sm-6 -->
      <div class="col-sm-6">
        <nav class="navbar navbar-default" role="navigation">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">Terms of use</a></li>
            <li><a href="#">Privacy policy</a></li>
          </ul>
        </nav>
      </div><!-- col-sm-6 -->
    </div><!-- row -->
  </div><!-- content container -->
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="js/myscript.js"></script>
</body>
</html>
