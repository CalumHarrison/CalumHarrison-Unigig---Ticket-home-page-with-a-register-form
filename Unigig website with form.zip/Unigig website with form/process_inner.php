<!DOCTYPE html>
<html>
<body>
<p>hello world</p>
<?php
//session start//
session_start();
//php connect to the server//
$con = mysql_connect("localhost","hnd15har12121031","password");
if (!$con){die('Could not connect: ' . mysql_error());}
//allow for a double query for a insertion into the database //
mysql_select_db("hnd15har12121031", $con);
mysql_query("SELECT Customer.*, order.*
FROM Customer
INNER JOIN order
ON Customer.order=OrderID;
mysql_close($con)
